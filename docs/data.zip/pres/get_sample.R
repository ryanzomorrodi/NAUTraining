library(tidyverse)
library(sf)
library(tigris)

PLACES <- read_csv("data/US/PLACES2023/PLACES2023_county.csv")
PLACES_doc <- read_csv("data/US/PLACES2023/PLACES_DataDictionary.csv")
measures <- PLACES_doc$MeasureID
AZ <- counties(state = "AZ") %>%
    st_transform("EPSG:26949") %>%
    as_tibble() %>%
    st_as_sf()
hospitals <- st_read("data/AZ/hospitals") %>%
    st_transform("EPSG:26949")


AZ_hosp_count <- AZ %>%
    st_join(hospitals) %>%
    group_by(GEOID) %>%
    summarize(`Hospital Count` = n()) %>%
    left_join(PLACES, join_by(GEOID == CountyFIPS)) %>%
    rename(Population = TotalPopulation) %>%
    relocate(geometry, .after = last_col()) %>%
    select(-ends_with("95CI")) %>%
    rename_with(
        .cols = ends_with("_CrudePrev"),
        .fn = ~ str_replace(.x, "_CrudePrev", " Crude Prevalence")
    ) %>%
    rename_with(
        .cols = ends_with("_AdjPrev"),
        .fn = ~ str_replace(.x, "_AdjPrev", " Adjusted Prevalence")
    ) %>%
    rename_with(
        .cols = c(contains(" "), -contains("Hospital")),
        .fn = ~ map_chr(.x, function (name) {
            paste0(PLACES_doc$`Measure short name`[measures == word(name, 1)], str_replace(name, word(name, 1), ""))
        })
    )

AZ_hosp_count %>%
    st_write("data/pres/sample.geojson", append = FALSE)
